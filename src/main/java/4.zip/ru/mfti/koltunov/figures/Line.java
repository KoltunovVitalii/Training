package ru.mfti.koltunov.figures;

public class Line implements LehgthOfLines {
    private Point2D start;
    private Point2D end;

    public Line(Point2D start, Point2D end) {
        this.start = start;
        this.end = end;
    }

    public Line(int startX, int startY, int endX, int endY) {
        this(new Point2D(startX, startY), new Point2D(endX, endY));
    }

    @Override
    public String toString() {
        return "Линия. " +
                "start=" + start +
                ", end=" + end;
    }

    public Point2D getStart() {
        return start;
    }

    public void setStart(Point2D start) {
        this.start = new Point2D(start);
    }

    public Point2D getEnd() {
        return end;
    }

    public void setEnd(Point2D end) {
        this.end = new Point2D(end);
    }

    public double getLength() {
        double length = Math.sqrt(Math.pow(start.getX() - end.getX(), 2) + Math.pow(start.getY() - end.getY(), 2));
        return length;
    }

    @Override
    protected Object clone() throws CloneNotSupportedException {
        Line line = new Line(start, end);
        line.start = this.start;
        line.end = this.end;
        return line;
    }
}

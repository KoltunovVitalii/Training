package ru.mfti.koltunov.figures;

import java.util.Arrays;

public class BrokenLine implements LehgthOfLines, BrokenLineable{
    public Point2D[] point2D;

    public BrokenLine() {
    }

    public BrokenLine(Point2D[] point2D) {
        this();
        this.point2D = point2D;
    }

    @Override
    public String toString() {
        return "Ломаная" + Arrays.toString(point2D);
    }


    public Point2D[] append(Point2D[] newPoint2DS) {
        Point2D[] point2DS = new Point2D[point2D.length + newPoint2DS.length];
        int count = 0;
        for (int i = 0; i < point2D.length; i++) {
            point2DS[i] = point2D[i];
            count++;
        }
        for (int j = 0; j < newPoint2DS.length; j++) {
            point2DS[count++] = newPoint2DS[j];
        }
        return point2DS;
    }

    public double getLength() {
        if (point2D.length < 1) return 0;
        double length = 0;
        for (int i = 0; i < point2D.length - 1; i++) {
            length = length + Math.sqrt(Math.pow(point2D[i].getX() - point2D[i+1].getX(), 2)
                    + Math.pow(point2D[i].getY() - point2D[i+1].getY(), 2));
        }
        return length;
    }

    @Override
    public BrokenLine getPolygonalChain() {
        return new BrokenLine(getPolygonalChain().point2D);
    }

}


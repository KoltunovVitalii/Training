package ru.mfti.koltunov.figures;

public interface BrokenLineable {
    public BrokenLine getPolygonalChain();
}

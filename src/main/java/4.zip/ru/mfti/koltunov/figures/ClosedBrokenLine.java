package ru.mfti.koltunov.figures;

public class ClosedBrokenLine extends BrokenLine {
    public ClosedBrokenLine() {
        super();
    }

    public ClosedBrokenLine(Point2D[] point2D) {
        super(point2D);
    }

    public double getLength() {
        double result = super.getLength();
        if(super.getLength() > 1) {
            result += super.getLength() + (Math.sqrt(Math.pow(point2D[point2D.length].getX() - point2D[0].getX(), 2)
                    + Math.pow(point2D[point2D.length].getY() - point2D[0].getY(), 2)));
        }
        return result;
    }
}

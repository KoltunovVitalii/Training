package ru.mfti.koltunov.figures;

public interface LehgthOfLines {
    public double getLength();
}

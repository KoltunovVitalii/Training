package ru.mfti.koltunov.cat;

public interface Meowing {
    public void meow();
}

package ru.mfti.koltunov.city;

public class Roads {
    City city;
    int price;

    public Roads(City city) {
        this.city = city;
    }

    public Roads(City city, int price) {
        this(city);
        this.price = price;
    }

    @Override
    public String toString() {
        return city + " " + price;
    }

    public City getCity() {
        return city;
    }

    public void setCity(City city) {
        this.city = city;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
}

package ru.mfti.koltunov.city;

import java.util.List;

public class City {
    private String name;
    private List<Roads> roads;

    public City(City city) {
        this(city.getName(), city.getRoads());
    }

    public City(String name, Roads... roads) {
        setName(name);
        setRoads(roads);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Roads[] getRoads() {
        return roads.toArray(Roads[]::new);
    }

    public void setRoads(Roads... roads) {
        this.roads.clear();
        setRoads(roads);
    }

    public void addRoads(Roads... roads) {
        up: for (int i = 0; i < roads.length; i++) {
            City city = roads[i].getCity();
            for (int j = 0; j < this.roads.size(); j++) {
                if (this.roads.get(j).getCity() == city) {
                    this.roads.get(j).setPrice(roads[i].price);
                    continue up;
                }
            }
            this.roads.add(roads[i]);
        }
    }

    @Override
    public String toString() {
        if (roads != null) {
            return "Город: " + name + " " + "Маршруты: " + roads;
        }
        return "Город: " + name + " " + "Маршрутов нет";
    }
}


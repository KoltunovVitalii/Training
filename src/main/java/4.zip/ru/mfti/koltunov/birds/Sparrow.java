package ru.mfti.koltunov.birds;

public class Sparrow extends Birds {
    public Sparrow() {
    }

    @Override
    public void song() {
        System.out.println("чырык");
    }
}

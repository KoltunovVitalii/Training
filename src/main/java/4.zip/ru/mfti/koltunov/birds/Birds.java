package ru.mfti.koltunov.birds;

public abstract class Birds {


    public abstract void song();

}

